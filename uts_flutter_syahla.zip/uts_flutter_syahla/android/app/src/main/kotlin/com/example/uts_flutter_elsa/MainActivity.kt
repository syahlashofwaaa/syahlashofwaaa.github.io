package com.example.uts_flutter_elsa

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
